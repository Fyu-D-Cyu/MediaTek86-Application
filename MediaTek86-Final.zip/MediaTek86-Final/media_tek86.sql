-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 24 mai 2026 à 14:10
-- Version du serveur : 8.4.7
-- Version de PHP : 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `media tek86`
--

-- --------------------------------------------------------

--
-- Structure de la table `absence`
--

DROP TABLE IF EXISTS `absence`;
CREATE TABLE IF NOT EXISTS `absence` (
  `idpersonnel` int NOT NULL,
  `datedebut` datetime NOT NULL,
  `datefin` datetime DEFAULT NULL,
  `idmotif` int NOT NULL,
  PRIMARY KEY (`idpersonnel`,`datedebut`),
  KEY `idmotif` (`idmotif`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `absence`
--

INSERT INTO `absence` (`idpersonnel`, `datedebut`, `datefin`, `idmotif`) VALUES
(4, '2025-10-05 14:55:18', '2027-01-19 01:24:59', 2),
(5, '2025-12-06 23:53:56', '2027-01-10 05:59:48', 1),
(10, '2025-12-22 19:50:34', '2027-03-23 07:44:02', 3),
(4, '2025-12-06 14:33:17', '2026-09-05 04:19:23', 2),
(4, '2025-10-09 13:12:50', '2026-11-21 06:24:41', 1),
(6, '2026-04-10 19:08:22', '2026-11-06 12:05:17', 4),
(8, '2026-03-13 09:26:02', '2026-09-10 15:10:22', 3),
(5, '2026-03-19 00:23:53', '2026-10-01 20:22:11', 2),
(5, '2025-12-17 17:56:17', '2027-04-03 05:02:25', 3),
(3, '2025-11-12 15:54:11', '2026-12-28 04:00:59', 4),
(7, '2025-09-24 07:16:52', '2027-04-16 19:28:50', 3),
(3, '2025-12-12 13:48:00', '2026-11-28 22:57:29', 1),
(8, '2026-05-11 01:35:37', '2026-05-29 16:31:04', 4),
(4, '2026-04-27 21:54:14', '2027-04-11 07:24:54', 3),
(4, '2025-11-14 00:36:00', '2027-01-08 09:59:40', 3),
(4, '2026-03-19 03:24:57', '2026-12-01 23:26:35', 4),
(7, '2025-12-01 12:56:30', '2026-11-03 04:55:09', 4),
(10, '2025-09-05 04:54:09', '2026-08-16 17:37:36', 3),
(2, '2026-01-01 12:57:48', '2027-02-10 22:16:18', 3),
(4, '2026-01-05 15:05:26', '2027-01-02 17:42:26', 2),
(9, '2025-07-17 22:10:54', '2026-06-03 16:05:55', 4),
(9, '2026-05-01 22:42:57', '2026-07-18 20:12:20', 1),
(6, '2025-07-15 09:10:20', '2026-11-17 03:19:00', 3),
(4, '2025-09-08 04:58:59', '2026-07-03 00:12:38', 3),
(10, '2026-03-01 01:48:05', '2026-10-14 03:22:25', 3),
(6, '2025-07-31 07:11:31', '2027-03-05 12:46:29', 1),
(10, '2026-03-21 12:10:37', '2027-03-03 03:20:04', 3),
(6, '2026-04-20 13:29:16', '2027-01-15 19:47:10', 3),
(6, '2025-05-30 08:58:10', '2026-09-27 14:20:00', 2),
(3, '2025-10-25 22:40:52', '2026-08-16 08:49:06', 2),
(1, '2026-04-17 13:33:55', '2027-03-23 01:30:40', 2),
(8, '2026-03-11 10:57:09', '2027-01-28 15:50:58', 2),
(3, '2025-05-24 13:29:41', '2026-11-01 05:59:57', 3),
(10, '2025-11-10 00:15:25', '2026-08-07 12:11:14', 1),
(10, '2025-06-11 16:06:40', '2026-10-15 01:44:56', 3),
(2, '2026-03-30 00:32:36', '2027-05-23 04:34:44', 2),
(2, '2026-05-03 14:09:26', '2026-07-30 02:54:50', 2),
(6, '2025-06-22 15:35:09', '2026-09-03 11:01:41', 3),
(8, '2025-12-07 19:55:04', '2027-05-12 01:21:37', 3),
(5, '2025-06-27 20:09:23', '2026-07-14 10:29:20', 3),
(5, '2026-01-29 21:41:36', '2027-03-29 14:56:48', 1),
(7, '2025-06-22 12:13:30', '2027-03-25 23:48:02', 1),
(2, '2025-06-09 00:17:58', '2026-10-22 00:41:16', 3),
(7, '2025-05-31 09:54:17', '2027-03-12 03:54:12', 3),
(9, '2025-12-24 03:29:55', '2026-07-01 01:10:28', 4),
(7, '2026-04-18 05:50:14', '2026-12-14 23:16:14', 2),
(6, '2026-01-09 15:18:32', '2026-08-15 18:06:07', 3),
(4, '2025-07-19 01:13:18', '2026-05-29 23:47:34', 3),
(9, '2026-03-16 14:19:24', '2027-04-08 07:40:48', 3);

-- --------------------------------------------------------

--
-- Structure de la table `motif`
--

DROP TABLE IF EXISTS `motif`;
CREATE TABLE IF NOT EXISTS `motif` (
  `idmotif` int NOT NULL AUTO_INCREMENT,
  `libelle` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idmotif`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `motif`
--

INSERT INTO `motif` (`idmotif`, `libelle`) VALUES
(1, 'vacances'),
(2, 'maladie'),
(3, 'motif familial'),
(4, 'congé parental');

-- --------------------------------------------------------

--
-- Structure de la table `personnel`
--

DROP TABLE IF EXISTS `personnel`;
CREATE TABLE IF NOT EXISTS `personnel` (
  `idpersonnel` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prenom` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tel` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idservice` int NOT NULL,
  PRIMARY KEY (`idpersonnel`),
  KEY `idservice` (`idservice`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `personnel`
--

INSERT INTO `personnel` (`idpersonnel`, `nom`, `prenom`, `tel`, `mail`, `idservice`) VALUES
(1, 'Medina', 'Whoopi', '05 53 18 72 17', 'wmedina@gmail.com', 1),
(2, 'House', 'Noelani', '04 55 22 44 68', 'h_noelani6152@gmail.com', 2),
(3, 'Robbins', 'Iona', '03 77 58 58 93', 'iona_robbins@gmail.com', 2),
(4, 'Mcmahon', 'Germaine', '04 60 37 87 47', 'germainemcmahon@gmail.com', 1),
(5, 'Douglas', 'Lucian', '03 33 98 99 32', 'lucian_douglas@gmail.com', 3),
(6, 'Reese', 'Kay', '06 97 22 38 38', 'kay.reese2244@gmail.com', 2),
(7, 'Turner', 'Hop', '08 13 73 78 63', 'hop-turner@gmail.com', 2),
(8, 'Allen', 'Zachery', '03 03 88 22 34', 'zachery-allen8895@gmail.com', 3),
(9, 'Mcclain', 'Magee', '07 38 35 51 82', 'm_magee@gmail.com', 3),
(10, 'Grimes', 'Vivien', '07 28 75 55 77', 'viviengrimes8716@gmail.com', 2);

-- --------------------------------------------------------

--
-- Structure de la table `responsable`
--

DROP TABLE IF EXISTS `responsable`;
CREATE TABLE IF NOT EXISTS `responsable` (
  `login` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pwd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `responsable`
--

INSERT INTO `responsable` (`login`, `pwd`) VALUES
('admin', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4');

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

DROP TABLE IF EXISTS `service`;
CREATE TABLE IF NOT EXISTS `service` (
  `idservice` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idservice`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `service`
--

INSERT INTO `service` (`idservice`, `nom`) VALUES
(1, 'administratif'),
(2, 'médiation culturelle'),
(3, 'prêt');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
